
public class ADTListTest {
	
	public static void main(String[] args) {
		
		ListReferenceBased list = new ListReferenceBased();
		//creates a new list object
		
		System.out.println("Is the list empty? "+list.isEmpty());
		
		list.add(1, 2);
		list.add(2, 4);
		list.add(3, 6);
		list.add(4, 8);
		list.add(5, 10);
	
		
		System.out.println("Is the list empty? "+list.isEmpty());
		
		
		list.remove(1);
		
		System.out.println("index 1 is removed ");
		System.out.println("List size "+list.size());
		
		System.out.println("Adding an index to the list");
		list.add(1, 12);
		list.add(6, 2);
		System.out.println();
		System.out.println("List size "+list.size());
		System.out.println();
		ListReferenceBased.listLargest(list);
		ListReferenceBased.displayList(list);
		
		
	}//close main

}//close ADTListTest

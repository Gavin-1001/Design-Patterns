
public class ListTest {
	
	public static void main(String[] args) {
		
		ListArrayBased list = new ListArrayBased();
		
		list.add(1, "Apples");
		list.add(2, "Oranges");
		list.add(3, "Pears");
		list.add(4, "Bananas");
		
		
		System.out.println("Is the list empty? "+list.isEmpty());
		System.out.println();
		System.out.println("Size of the list "+list.size());
		
		System.out.println();
		
		list.remove(4);
		System.out.println();
		System.out.println("Size of the list "+list.size());
		System.out.println();
		list.add(4, "Pineapple");
		System.out.println("Is the list empty? "+list.isEmpty());
		System.out.println();
		System.out.println("Size of the list "+list.size());
		System.out.println();
		list.removeAll();
		System.out.println("Size of the list "+list.size());
		
	}//close main
	
	
	
	public static void displayList(ListArrayBased list) {
		
		for(int i = 0; i < list.size(); i++) {
			System.out.println("Items in the list: "+list.get(i));
			
			
		}//close for
		
	}//close displayList
}//close ListTest

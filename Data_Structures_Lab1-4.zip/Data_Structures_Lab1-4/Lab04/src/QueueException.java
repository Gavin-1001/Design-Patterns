public class QueueException extends RuntimeException
{

  public QueueException(String s)
  {
    super(s);
  }  // end constructor
}  // end QueueException
public class StackException extends java.lang.RuntimeException
{
  public StackException(String s)
  {
    super(s);
  }  // end constructor
}  // end StackException

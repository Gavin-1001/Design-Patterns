import java.util.*;


public class stackTest {
	
	public static void main(String[] args) {
		
		String str = "navan";
		String string = "palindrome";
		System.out.println("Is the string '" + str + "' balanced? : " + isBalanced(str, string));
		
		
		
		StackReferenceBased stack = new StackReferenceBased();
		
		stack.push("1");
		stack.push("2");
		stack.push("3");
		stack.push("4");
		stack.push("5");
		
		
		
		stack.pop();
		
		stack.push("10");
		stack.push("20");
		stack.push("30");
		stack.push("40");
		stack.push("50");
		
		stack.popAll();
	
		
		stack.push("100");
		stack.push("200");
		stack.push("300");
		stack.push("400");
		stack.push("500");
		
		stack.peek();
			}//close main
		public static boolean isBalanced(String str, String string) {
			
			Stack<Character> balanceStack = new Stack<Character>();
	        for(int i = 0; i < str.length(); ++i) {
	        	
	            if(str.charAt(i) == '{') {
	            	balanceStack.push(str.charAt(i));
	            }  	
	            else if(!balanceStack.empty() && str.charAt(i) == '}') {
	            	balanceStack.pop();
	            }
	            else if(balanceStack.empty() && str.charAt(i) == '}') {
	            	return false;
					
					
				}//close else if
				
			}//close for
			
			return balanceStack.empty();
		}//close isBalanced
		
		

	

}//close stackTest
